const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const session = require('express-session');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');
const app = express();

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: false,
    maxAge: 1000 * 60 * 60
  }
}));
const fileUpload = require('express-fileupload');
app.use(fileUpload());
app.post('/employee/upload/:type/:id', async (req, res) => {
  const accessToken = req.session.accessToken;
  const employeeId = req.params.id;
  const type = req.params.type;

  // multer-like manual file handling
  if (!req.files || !req.files.file) {
    return res.send('❌ لا يوجد ملف مرفوع');
  }

  const file = req.files.file;
  const tempPath = path.join(__dirname, 'temp', file.name);

  try {
    await file.mv(tempPath);

    const form = new FormData();
    form.append('file', fs.createReadStream(tempPath));

    await axios.post(`http://localhost:3000/employee/upload/${type}/${employeeId}`, form, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        ...form.getHeaders()
      }
    });

    fs.unlinkSync(tempPath);
    res.redirect('/usage');
  } catch (error) {
    console.error('❌ خطأ في رفع الصورة:', error.message);
    res.send('❌ فشل رفع الصورة');
  }
});

// ✅ صفحة تسجيل الدخول
app.get('/login', (req, res) => {
  res.render('login');
});

app.post('/login-company', async (req, res) => {
  const { email, password } = req.body;

  try {
    const response = await axios.post('http://localhost:3000/company/login', { email, password });
    const { accessToken } = response.data;
    req.session.accessToken = accessToken;

    const profileRes = await axios.get('http://localhost:3000/company/profile', {
      headers: { Authorization: `Bearer ${accessToken}` }
    });

    const company = profileRes.data;
    req.session.companyId = company.id;

    const subRes = await axios.get(`http://localhost:3000/company/${company.id}/subscription`, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });

    const subscription = subRes.data;

    if (subscription && subscription.plan) {
      return res.redirect('/usage');
    }

    res.redirect('/plans');
  } catch (error) {
    console.error('❌ خطأ في تسجيل الدخول:', error.message);
    res.send('❌ فشل تسجيل الدخول');
  }
});

// ✅ صفحة التسجيل
app.get('/register', (req, res) => {
  res.render('register');
});

app.post('/register-company', async (req, res) => {
  const { name, email, password, phone, logoUrl, description } = req.body;

  try {
    const response = await axios.post('http://localhost:3000/company', {
      name, email, password, phone, logoUrl, description,
      isActive: true, role: 'company'
    });

    const company = response.data;
    res.send(`✅ تم تسجيل الشركة بنجاح. ID: ${company.id}`);
  } catch (error) {
    console.error('❌ خطأ في التسجيل:', error.message);
    res.send('❌ فشل التسجيل');
  }
});

// ✅ عرض الخطط
app.get('/plans', async (req, res) => {
  const companyId = req.session.companyId;

  try {
    const response = await axios.get('http://localhost:3000/plans');
    const plans = response.data;

    res.render('plans', { plans, companyId });
  } catch (error) {
    console.error('❌ خطأ في تحميل الخطط:', error.message);
    res.send('❌ فشل تحميل الخطط');
  }
});

// ✅ الاشتراك في خطة
app.post('/subscribe', async (req, res) => {
  const { planId } = req.body;
  const companyId = req.session.companyId;
  const accessToken = req.session.accessToken;

  try {
    const response = await axios.post(`http://localhost:3000/company/${companyId}/subscribe/${planId}`, {}, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });

    const result = response.data;
    if (result.redirectToDashboard) return res.redirect('/usage');
    res.send(result.message);
  } catch (error) {
    console.error('❌ خطأ في الاشتراك:', error.message);
    res.send('❌ فشل الاشتراك في الخطة');
  }
});

// ✅ عرض حالة الاشتراك والموظفين
app.get('/usage', async (req, res) => {
  const companyId = req.session.companyId;
  const accessToken = req.session.accessToken;

  try {
    const subRes = await axios.get(`http://localhost:3000/company/${companyId}/subscription`, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
    const currentSubscription = subRes.data;

    const empRes = await axios.get(`http://localhost:3000/employee`, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
    const employeeList = empRes.data;

    const employees = employeeList.map(emp => ({
      id: emp.id,
      name: emp.name,
      email: emp.email,
      jobTitle: emp.jobTitle,
      phone: emp.phone,
      whatsapp: emp.whatsapp,
      location: emp.location,
      cardUrl: emp.cardUrl,
      qrCode: emp.qrCode || null
    }));

    res.render('usage', {
      usage: {
        currentSubscription,
        employees
      }
    });
  } catch (error) {
    console.error('❌ خطأ في تحميل بيانات الاشتراك أو الموظفين:', error.message);
    res.send('❌ فشل تحميل بيانات الاشتراك أو الموظفين');
  }
});

// ✅ إضافة موظف جديد (كامل الحقول)
app.post('/add-employee', async (req, res) => {
  const accessToken = req.session.accessToken;
  const {
    name,
    email,
    jobTitle,
    phone,
    whatsapp,
    location,
    smsNumber,
    faxNumber,
    about,
    profileImageUrl,
    secondaryImageUrl,
    facebook,
    instagram,
    tiktok,
    snapchat,
    workLink,
    productsLink
  } = req.body;

  try {
    await axios.post('http://localhost:3000/employee', {
      name,
      email,
      jobTitle,
      phone,
      whatsapp,
      location,
      smsNumber,
      faxNumber,
      about,
      profileImageUrl,
      secondaryImageUrl,
      facebook,
      instagram,
      tiktok,
      snapchat,
      workLink,
      productsLink
    }, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });

    res.redirect('/usage');
  } catch (error) {
    console.error('❌ خطأ في إضافة الموظف:', error.message);
    res.send('❌ فشل إضافة الموظف');
  }
});

// ✅ تعديل موظف
app.post('/update-employee', async (req, res) => {
  const accessToken = req.session.accessToken;
  const {
    id,
    name,
    email,
    jobTitle,
    phone,
    whatsapp,
    location,
    smsNumber,
    faxNumber,
    about,
    profileImageUrl,
    secondaryImageUrl,
    facebook,
    instagram,
    tiktok,
    snapchat,
    workLink,
    productsLink
  } = req.body;

  try {
    await axios.put(`http://localhost:3000/employee/${id}`, {
      name,
      email,
      jobTitle,
      phone,
      whatsapp,
      location,
      smsNumber,
      faxNumber,
      about,
      profileImageUrl,
      secondaryImageUrl,
      facebook,
      instagram,
      tiktok,
      snapchat,
      workLink,
      productsLink
    }, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });

    res.redirect('/usage');
  } catch (error) {
    console.error('❌ خطأ في تعديل الموظف:', error.message);
    res.send('❌ فشل تعديل الموظف');
  }
});

// ✅ حذف موظف
app.post('/delete-employee', async (req, res) => {
  const accessToken = req.session.accessToken;
  const { id } = req.body;

  try {
    await axios.delete(`http://localhost:3000/employee/${id}`, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });

    res.redirect('/usage');
  } catch (error) {
    console.error('❌ خطأ في حذف الموظف:', error.message);
    res.send('❌ فشل حذف الموظف');
  }
});

// ✅ عرض بطاقة الموظف
app.get('/card/:uniqueUrl', async (req, res) => {
  const { uniqueUrl } = req.params;

  try {
    const response = await axios.get(`http://localhost:3000/employee/by-url/${uniqueUrl}`);
    const employee = response.data;
    res.render('card', { employee });
  } catch (error) {
    console.error('❌ خطأ في تحميل بيانات الموظف:', error.message);
    res.send('❌ فشل تحميل البطاقة');
  }
});

app.listen(4000, () => {
  console.log('✅ Frontend running on http://localhost:4000');
});
